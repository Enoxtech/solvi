import type React from "react"
import Link from "next/link"

export default function Layout({ children }: { children: React.ReactNode }) {
  return (
    <div className="min-h-screen flex flex-col">
      <header className="bg-deep-blue text-white p-4">
        <div className="container mx-auto flex justify-between items-center">
          <Link href="/" className="text-2xl font-bold">
            Velocia
          </Link>
          <nav>
            <ul className="flex space-x-4">
              <li>
                <Link href="/currency-exchange" className="hover:text-sky-blue">
                  Currency Exchange
                </Link>
              </li>
              <li>
                <Link href="/logistics" className="hover:text-sky-blue">
                  Logistics
                </Link>
              </li>
              <li>
                <Link href="/bill-payments" className="hover:text-sky-blue">
                  Bill Payments
                </Link>
              </li>
              <li>
                <Link href="/wallet" className="hover:text-sky-blue">
                  Wallet
                </Link>
              </li>
              <li>
                <Link href="/dashboard" className="hover:text-sky-blue">
                  Dashboard
                </Link>
              </li>
              <li>
                <Link href="/community" className="hover:text-sky-blue">
                  Community
                </Link>
              </li>
            </ul>
          </nav>
        </div>
      </header>
      <main className="flex-grow container mx-auto p-4">{children}</main>
      <footer className="bg-charcoal text-white p-4 text-center">
        <p>&copy; 2025 Velocia. All rights reserved.</p>
      </footer>
    </div>
  )
}

